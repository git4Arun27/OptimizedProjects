# 10ItemDetection > 2024-10-14 10:13am
https://universe.roboflow.com/object-detection-using-yolov5-utvob/10itemdetection

Provided by a Roboflow user
License: Public Domain

